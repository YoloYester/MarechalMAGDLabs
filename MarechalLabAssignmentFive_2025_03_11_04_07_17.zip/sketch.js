let hideEi = false;
let hideRi1 = false;
let changeRi2 = false;

function setup() {
  createCanvas(500, 500);
describe('Below (and above) is the code for a custom-made theme, which is used to resemble a TV screen. Six rectangles make up the main screen, and below it are 3 buttons decorated with care. The center button is a basic white and navy structure. When the mouse is in its bounds and the SPACEBAR is pressed, the big rectangle behind the others turns into a deep blue. To the right of that button is another button with a color theme surrounding smaragdine, a fancy shade of green. When the mouse is in the bounds of the button and then is pressed and released, the opacity of the hot purple and pink rectangles is inverted. To the right of that button is a button with a color theme surrounding amaranth, a fancy shade of red. When the mouse is clicked in the bounds of this button, the opacity of the red, dark orange, and orange rectangles is inverted. The stroke of the large backdrop rectangle gives the illusion of color change, when in actuality the coming of opacity in rectangles makes their color the same as the background color.');
}

function draw() {
  background(110);

  let q1 = color('#E670B7');
  let q2 = color('#E67157');
  let q3 = color('#E64241');
  let q4 = color('#CD02E6');
  let q5 = color('#E67335');
  let q6 = color('#E3AFAF');
  let q7 = color('#420694');

  if (changeRi2) {
    fill(q7);
  } else {
    fill(q6);
  }
  rect(20, 20, 460, 400);
  noStroke();
  if (!hideEi) {
    fill(q5);
    rect(55, 20, 70, 400);
    fill(q3);
    rect(215, 20, 70, 400);
    fill(q2);
    rect(295, 20, 70, 400);
  } else {
    fill(110);
    rect(55, 20, 70, 400);
    rect(215, 20, 70, 400);
    rect(295, 20, 70, 400);
  }

  if (!hideRi1) {
    fill(q4);
    rect(135, 20, 70, 400);
    fill(q1);
    rect(375, 20, 70, 400);
  } else {
    fill(110);
    rect(135, 20, 70, 400);
    rect(375, 20, 70, 400);
  }

  fill('#9E7965');
  strokeWeight(3);
  stroke('#381614');
  ellipseMode(CENTER);
  ellipse(450, 465, 40, 40);

  fill('#651C25');
  strokeWeight(2);
  stroke('#E0A092');
  ellipseMode(RADIUS);
  ellipse(450, 465, 20, 10);

  fill('#A5CCBB');
  stroke('#80B89F');
  rect(350, 445, 60, 30);

  fill('#92C2AD');
  strokeWeight(1);
  stroke('#4A9976');
  rect(360, 445, 40, 30);

  fill('#FFFFFF');
  stroke('#000094');
  rect(230, 445, 90, 30);
  rect(245, 445, 60, 30);
}

function mousePressed() {
  if (dist(mouseX, mouseY, 450, 465) < 20) {
    hideEi = !hideEi;
  }
}

function mouseClicked() {
  if (mouseX > 350 && mouseX < 410 && mouseY > 445 && mouseY < 475) {
    hideRi1 = !hideRi1;
  }
}

function keyPressed() {
  if (key === ' ') {
    if (mouseX > 230 && mouseX < 320 && mouseY > 445 && mouseY < 475) {
      changeRi2 = !changeRi2;
    }
  }
}