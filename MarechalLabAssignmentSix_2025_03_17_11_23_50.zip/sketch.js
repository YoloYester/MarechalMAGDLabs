let wisps = [];
let spiders = [];
let numWisps = 6;
let numSpiders = 4;

function setup() {
  createCanvas(500, 500);
  background(30);
  noFill();

  describe("Six ghosts and four spiders move around a dark background. Spiders move at a speed based on their size. Wisps move erratically. By clicking, ghosts will follow the mouse. When ghosts move, they spread ectoplasm that make the background brighter. When spiders move, their steps make the background darker. Ghosts phase through the spiders since the spiders are living and the ghosts are dead.");

  for (let i = 0; i < numWisps; i++) {
    wisps.push({
      x: random(width),
      y: random(height),
      targetX: random(width),
      targetY: random(height)
    });
  }

  for (let i = 0; i < numSpiders; i++) {
    spiders.push({
      x: random(width),
      y: random(height),
      size: random(10, 20),
      speedX: random(-1, 1),
      speedY: random(-1, 1)
    });
  }

  print("Wisps Array Length:", wisps.length);
  print("Spiders Array Length:", spiders.length);
}

function draw() {
  background(30, 50);

  for (let i = 0; i < wisps.length; i++) {
    let w = wisps[i];
    w.x = lerp(w.x, w.targetX, 0.02);
    w.y = lerp(w.y, w.targetY, 0.02);

    if (frameCount % 120 === 0) {
      w.targetX = random(width);
      w.targetY = random(height);
    }

    fill(224, 224, 255, 180);
    stroke(200, 150);
    for (let j = 0; j < 6; j++) {
      ellipse(w.x, w.y, 30 + j * 3, 40 + j * 3);
    }

    stroke(255, 0, 5);
    fill(0);
    ellipse(w.x - 5, w.y - 5, 5, 5);
    ellipse(w.x + 5, w.y - 5, 5, 5);
    noFill();
  }

  for (let i = 0; i < spiders.length; i++) {
    let s = spiders[i];
    s.x += s.speedX;
    s.y += s.speedY;
    
    if (s.x < 10 || s.x > width - 10) s.speedX *= -1;
    if (s.y < 10 || s.y > height - 10) s.speedY *= -1;

    noStroke();
    fill(20);
    ellipse(s.x, s.y, s.size, s.size);

    stroke(20);
    let angles = [-75, -60, -45, -30, 30, 45, 60, 75];
    for (let j = 0; j < angles.length; j++) {
      let angle = radians(angles[j]);
      let xOffset = cos(angle) * s.size;
      let yOffset = sin(angle) * s.size;
      line(s.x, s.y, s.x + xOffset, s.y + yOffset);
      line(s.x + xOffset, s.y + yOffset, s.x + xOffset * 1.5, s.y + yOffset * 1.5);
    }

    fill(255, 30, 0);
    let eyeOffsetX = s.size * 0.25;
    let eyeOffsetY = s.size * 0.2;
    ellipse(s.x - eyeOffsetX, s.y - eyeOffsetY, 4, 4);
    ellipse(s.x + eyeOffsetX, s.y - eyeOffsetY, 4, 4);
    ellipse(s.x - eyeOffsetX * 0.7, s.y + eyeOffsetY, 4, 4);
    ellipse(s.x + eyeOffsetX * 0.7, s.y + eyeOffsetY, 4, 4);
    noFill();
  }

  if (mouseIsPressed) {
    let w = wisps[int(random(wisps.length))];
    w.targetX = mouseX;
    w.targetY = mouseY;
  }
}
