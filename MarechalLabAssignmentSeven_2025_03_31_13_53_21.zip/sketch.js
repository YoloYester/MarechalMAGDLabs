let angle = 0; 

function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  colorMode(RGB, 255, 255, 255, 1);
  console.log("Setup complete.");
  describe('Three stars rotate in the middle of a canvas. Their color is random every time the code is run. This color randomization is added as an aesthetic change to give a feel of personalization. This is inspired partially by Flappy Bird, a retro-like game, which can dish out randomly colored backgrounds and bird colors. FUN FACT: The odds of the same exact combination of 3 star colors appears barring position is 2^72. If position is considered, the number shoots up drastically to 2^216. For reference, the chances of winning the lottery are about 1 in 300 million, which is close to odds of 2^20, nowhere near as unlikely as the other two aforementioned scenarios.');
}

function draw() {
  background(50);
  noStroke();
  for (let i = 0; i < 3; i++) {
    let x = 150 + i * 100;
    let y = 250;
    let size = getSize(i); 
    let starColor = getColor(i);
    shape1(x, y, size * 0.5, size, 5, starColor);
  }

  angle += 1;
}

function getSize(index) {
  let size = 50 + index * 20;
  return size;
}

let starColors = [];

function getColor(index) {
  if (!starColors[index]) {
    let r = Math.floor(random(255));
    let g = Math.floor(random(255));
    let b = Math.floor(random(255));
    starColors[index] = color(r, g, b, 1); 
    print("Star " + (index+1) + " Color: RGB(" + r + ", " + g + ", " + b + ")");
  }
  return starColors[index];
}

function shape1(x, y, radius1, radius2, vertices, col) {
  push();
  translate(x, y);
  rotate(angle);
  scale(0.75); 
  
  fill(col);
  let angleStep = 360 / (vertices * 2);
  beginShape();
  for (let i = 0; i < vertices * 2; i++) {
    let r = (i % 2 === 0) ? radius2 : radius1;
    let xPos = cos(i * angleStep) * r;
    let yPos = sin(i * angleStep) * r;
    vertex(xPos, yPos);
  }
  endShape(CLOSE);
  
  pop();
}
